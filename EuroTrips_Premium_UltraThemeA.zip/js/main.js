/* main.js — fixed for Netlify production + defensive DOM guards */
console.log("DEBUG: Ultra-Premium main.js starting (netlify-safe)");

const config = {
  geocodeUrl: "https://geocoding-api.open-meteo.com/v1/search",
  sevenTimerUrl: "https://www.7timer.info/bin/api.pl",
  product: "civillight",
  output: "json",
};

const popularCities = ["London,UK","Paris,FR","Berlin,DE","Madrid,ES","Rome,IT","Lisbon,PT","Amsterdam,NL","Vienna,AT","Prague,CZ","Barcelona,ES"];

const el = {
  input: null, searchBtn: null, message: null, forecastGrid: null,
  popular: null, recent: null, unitC: null, unitF: null
};

function wireDom() {
  el.input = document.getElementById("city-input");
  el.searchBtn = document.getElementById("search-btn");
  el.message = document.getElementById("message");
  el.forecastGrid = document.getElementById("forecast");
  el.popular = document.getElementById("popular");
  el.recent = document.getElementById("recent");
  el.unitC = document.getElementById("unit-c");
  el.unitF = document.getElementById("unit-f");
  console.log("DEBUG: DOM wired:", {
    input: !!el.input, searchBtn: !!el.searchBtn, message: !!el.message, forecastGrid: !!el.forecastGrid,
    popular: !!el.popular, recent: !!el.recent, unitC: !!el.unitC, unitF: !!el.unitF
  });
}

/* UI helpers */
function setMessage(html) { if (el.message) el.message.innerHTML = html; else console.warn("no message node"); }
function showLoading(msg="Loading…") { setMessage(`${msg}<div class="spinner"></div>`); if (el.forecastGrid) el.forecastGrid.innerHTML = ""; }
function showText(msg) { setMessage(`<div class="small-muted">${msg}</div>`); if (el.forecastGrid) el.forecastGrid.innerHTML = ""; }

/* icons & units */
const ICON_MAP = { clear:"☀️", pcloudy:"⛅", mcloudy:"☁️", cloudy:"☁️", lightrain:"🌦️", ishower:"🌧️", rain:"🌧️", tstorm:"⛈️", ts:"⛈️", snow:"🌨️", lightsnow:"🌨️", humid:"💧", windy:"🌬️", frost:"🧊" };
function weatherIcon(code){ if(!code) return "🌡️"; code = String(code).toLowerCase(); return ICON_MAP[code] || ICON_MAP[code.split(",")[0]] || "🌡️"; }
let currentUnit = "C";
function convertTemp(val){ if(val === "—") return "—"; if(currentUnit === "C") return Math.round(val); return Math.round(val*1.8 + 32); }
function updateUnitUI(){ if(el.unitC) el.unitC.classList.toggle("active", currentUnit === "C"); if(el.unitF) el.unitF.classList.toggle("active", currentUnit === "F"); }

/* recent searches */
function loadRecentSearches(){ try { const d = JSON.parse(localStorage.getItem("recentSearches") || "[]"); return Array.isArray(d)?d:[] } catch(e){ return [] } }
function saveRecentSearch(city){ try { let list = loadRecentSearches(); list = [city, ...list.filter(c=>c!==city)].slice(0,6); localStorage.setItem("recentSearches", JSON.stringify(list)); renderRecent(); } catch(e){ console.warn("recent save failed", e) } }
function renderRecent(){ if(!el.recent) return; const list = loadRecentSearches(); el.recent.innerHTML = ""; list.forEach(city=>{ const btn = document.createElement("button"); btn.className = "recent-btn"; btn.textContent = city.split(",")[0]; btn.addEventListener("click", ()=>fetchForecastForCity(city)); el.recent.appendChild(btn) }) }

/* format date */
function formatDateLabel(rep){
  if(rep && rep.date && String(rep.date).length === 8){
    const s = String(rep.date); const yyyy = s.slice(0,4), mm = s.slice(4,6), dd = s.slice(6,8);
    const d = new Date(`${yyyy}-${mm}-${dd}T00:00:00Z`);
    return d.toLocaleDateString(undefined, {month:'short', day:'numeric', year:'numeric'});
  }
  if(rep && rep.timepoint != null){
    const future = new Date(Date.now() + rep.timepoint * 3600 * 1000);
    return future.toLocaleDateString(undefined, {month:'short', day:'numeric'});
  }
  return "Unknown";
}

/* render */
function renderForecast(cityDisplay, dataseries){
  if(!el.forecastGrid) { console.warn("no forecastGrid"); return; }
  el.message && (el.message.innerHTML = `<strong>${cityDisplay}</strong><div class="small-muted">7-day forecast</div>`);
  el.forecastGrid.innerHTML = "";
  if(!dataseries || dataseries.length === 0){ showText("No forecast data available."); return; }
  const groups = {};
  dataseries.forEach(item => {
    const key = item.date || String(Math.floor((item.timepoint||0)/24));
    if(!groups[key]) groups[key] = [];
    groups[key].push(item);
  });
  const keys = Object.keys(groups).slice(0,7);
  keys.forEach(k => {
    const bucket = groups[k];
    const rep = bucket.find(it => ((it.timepoint||0) % 24) >= 12 && ((it.timepoint||0) % 24) <= 15) || bucket[0];
    const dateLabel = formatDateLabel(rep);
    const icon = weatherIcon(rep && rep.weather);
    let tmax = "—", tmin = "—";
    if(rep && rep.temp2m){
      if(typeof rep.temp2m === "object"){ if(rep.temp2m.max != null) tmax = convertTemp(rep.temp2m.max); if(rep.temp2m.min != null) tmin = convertTemp(rep.temp2m.min); }
      else tmax = convertTemp(rep.temp2m);
    }
    const pop = (rep && rep.pop != null) ? `${rep.pop}%` : "—";
    const wind = rep && rep.wind10m && (rep.wind10m.speed || rep.wind10m) ? `${rep.wind10m.speed || rep.wind10m} m/s` : "—";
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div class="weather-ico">${icon}</div>
      <h4>${dateLabel}</h4>
      <div class="temp">${tmax}° / ${tmin}°</div>
      <div class="small">${(rep && rep.weather) || "N/A"} • precip ${pop} • wind ${wind}</div>
    `;
    el.forecastGrid.appendChild(card);
  });
}

/* caching */
function getCache(key){ try{ const raw = localStorage.getItem(key); if(!raw) return null; const obj = JSON.parse(raw); if(Date.now() - obj.ts > obj.ttl) return null; return obj.data; }catch(e){return null} }
function setCache(key, data, ttlSeconds){ try{ const obj = { ts: Date.now(), ttl: ttlSeconds * 1000, data }; localStorage.setItem(key, JSON.stringify(obj)); }catch(e){console.warn("cache set failed", e)} }

/* geocoding (robust) */
async function getCoordinates(city){
  if(!city) return null;
  const raw = String(city).trim();
  const attempts = [raw];
  if(raw.includes(",")){ const parts = raw.split(",").map(s=>s.trim()); if(parts[0]) attempts.push(parts[0]); }
  const cleaned = raw.replace(/\\(.+?\\)/g, "").replace(/[0-9]/g, "").trim();
  if(cleaned && !attempts.includes(cleaned)) attempts.push(cleaned);
  const nameOnly = raw.split(",")[0].trim().toLowerCase();
  const popMatch = popularCities.find(p => p.split(",")[0].toLowerCase() === nameOnly);
  if(popMatch && !attempts.includes(popMatch)) attempts.push(popMatch);

  for(const q of attempts){
    if(!q) continue;
    const url = `${config.geocodeUrl}?name=${encodeURIComponent(q)}&count=1&language=en&format=json`;
    try {
      const res = await fetch(url);
      if(!res.ok) { console.warn("geocode http", res.status, q); continue; }
      const j = await res.json();
      if(j && j.results && j.results.length > 0){
        const r = j.results[0];
        return { lat: r.latitude, lon: r.longitude, displayName: `${r.name}${r.admin1? ", "+r.admin1:""}, ${r.country_code}` };
      }
    } catch(err){
      console.warn("geocode fetch error for", q, err && err.message);
    }
  }
  return null;
}

/* call 7Timer — use Netlify function in production */
async function call7Timer(lat, lon){
  // if running on localhost, use local proxy path /api/forecast
  const isLocal = location.hostname === "localhost" || location.hostname === "127.0.0.1" || location.hostname === "::1";
  const url = isLocal ? `/api/forecast?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}` : `/.netlify/functions/forecast?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}`;
  console.log("DEBUG: calling forecast backend ->", url);
  const res = await fetch(url);
  if(!res.ok){
    const body = await res.text().catch(()=>"<no-body>");
    throw new Error(`Forecast backend error: ${res.status} ${body}`);
  }
  return res.json();
}

/* main flow */
async function fetchForecastForCity(city){
  if(!city) city = el.input ? el.input.value.trim() : "";
  if(!city) return showText("Please enter a city.");
  showLoading(`Searching ${city}…`);
  try{ saveRecentSearch(city); } catch(e){ console.warn("saveRecentSearch failed", e) }
  const cacheKey = `7t:${city.toLowerCase()}`;
  const cached = getCache(cacheKey);
  if(cached){ renderForecast(city, cached.dataseries || cached); return; }

  try {
    const coords = await getCoordinates(city);
    if(!coords) { showText('City not found. Try "Paris,FR".'); return; }
    const data = await call7Timer(coords.lat, coords.lon);
    setCache(cacheKey, data, 1800);
    renderForecast(coords.displayName || city, data.dataseries || data);
  } catch(err){
    console.error("fetchForecastForCity error:", err);
    showText("Could not load weather — " + (err && err.message ? err.message : "unknown"));
  }
}

/* popular rendering & safe bindings */
function renderPopular(){
  if(!el.popular) return;
  el.popular.innerHTML = "";
  popularCities.forEach(city => {
    const btn = document.createElement("button");
    btn.className = "city-btn";
    btn.textContent = city.split(",")[0];
    btn.addEventListener("click", ()=> fetchForecastForCity(city));
    el.popular.appendChild(btn);
  });
}

/* initialize */
function init(){
  wireDom();
  renderPopular();
  renderRecent();
  try { const yearNode = document.getElementById("year"); if(yearNode) yearNode.textContent = new Date().getFullYear(); } catch(e){}
  if(el.searchBtn) el.searchBtn.addEventListener("click", ()=> fetchForecastForCity());
  if(el.input) el.input.addEventListener("keydown", e => { if(e.key === "Enter") fetchForecastForCity(); });
  if(el.unitC) el.unitC.addEventListener("click", ()=> { currentUnit = "C"; updateUnitUI(); /* re-render if data present */ if(el.forecastGrid && el.forecastGrid.children.length) { const q = el.input && el.input.value ? el.input.value : null; fetchForecastForCity(q); } });
  if(el.unitF) el.unitF.addEventListener("click", ()=> { currentUnit = "F"; updateUnitUI(); if(el.forecastGrid && el.forecastGrid.children.length) { const q = el.input && el.input.value ? el.input.value : null; fetchForecastForCity(q); } });
  updateUnitUI();
  console.log("DEBUG: init complete");
}

document.addEventListener("DOMContentLoaded", init);
