const fetch = require('node-fetch');

function fixMalformedJson(text) {
  let fixed = text.replace(/"min"\s*:\s*(?=,|\n|\r|})/g, `"min" : 0`);
  fixed = fixed.replace(/,\s*(?=[}\]])/g, '');
  return fixed;
}

exports.handler = async (event) => {
  try {
    const { lat, lon } = event.queryStringParameters || {};
    if (!lat || !lon) {
      return { statusCode: 400, body: JSON.stringify({ error: 'lat and lon required' }) };
    }
    const url = `https://www.7timer.info/bin/api.pl?lon=${encodeURIComponent(lon)}&lat=${encodeURIComponent(lat)}&product=civillight&output=json`;
    console.log("Netlify Proxy ->", url);
    const response = await fetch(url, { timeout: 15000 });
    const text = await response.text();
    const cleaned = fixMalformedJson(text);
    try {
      const json = JSON.parse(cleaned);
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(json) };
    } catch (e) {
      console.error("Parse failed AFTER fix ->", e);
      return { statusCode: 502, body: JSON.stringify({ error: 'Invalid JSON (repair failed)', details: e.message, previewOriginal: text.slice(0,200), previewCleaned: cleaned.slice(0,200) }) };
    }
  } catch (err) {
    console.error("Netlify proxy error:", err);
    return { statusCode: 502, body: JSON.stringify({ error: 'Netlify function error', details: err.message }) };
  }
};
